     <div class="footer-wrapper style-4" style="background-color: #252525;">
                    <footer class="type-1">
                        <div class="footer-bottom-navigation">
                     
                                <div class="footer-links text-center">
                                    <a href="{{url('custom')}}">Custom Errand</a>
                                    <a href="{{url('verification')}}">Verify our Agent</a>
                                    <a href="#">Terms and Condition</a>
                                
                                    <a href="#">Returns Policy</a>
                                    <a href="{{url('contact')}}">Contact Us</a>
                                </div>
                                <div class="copyright text-center">All right reserved</div>
                       
                     
                        </div>
                    </footer>
                </div>





