<!-- jQuery -->
<script src="{{asset('cpanel/js/jquery.js')}}"></script>

<!-- Bootstrap Core JavaScript -->
<script src="{{asset('cpanel/js/bootstrap.min.js')}}"></script>







<script src="{{URL::to('parsley.min.js')}}"></script>

